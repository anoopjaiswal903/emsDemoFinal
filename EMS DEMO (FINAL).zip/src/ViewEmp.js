import React from "react";
import ShowEmployee from "./components/ShowEmployee";

function ViewEmp() {
  return (
    <div>
      <ShowEmployee />
    </div>
  );
}

export default ViewEmp;
